/** @file	stdafx.h 

	Include file for standard system include files, or project specific
	include files that are used frequently, but are changed infrequently
*/
#ifndef __px14_stdafx_header_defined
#define __px14_stdafx_header_defined

#include "px14_plat.h"

#endif // __px14_stdafx_header_defined


